/*
 * pacman.c
 */

/* Includes */
#include "pacman.h"
#include "button.h"
#include "lcd.h"
#include "led_7seg.h"

#include <stdlib.h>
#include <time.h>

/* Enums */
typedef enum DIRECTION {
	UP, DOWN, LEFT, RIGHT, STOP
} E_DIRECTION;

/* Struct */
typedef struct CELL {
	uint8_t is_pac_dot;
} S_CELL;

typedef struct MAZE {
	S_CELL cells[MAZE_COLUMN_N][MAZE_ROW_N];
} S_MAZE;

typedef struct GHOST {
	uint8_t i, j;
	uint8_t i_pre, j_pre;
	E_DIRECTION direction;
} S_GHOST;

typedef struct PACMAN {
	uint8_t i, j;
	uint8_t i_pre, j_pre;
	E_DIRECTION direction;
	int score;
} S_PACMAN;

/* Private Objects */
// Pac-Man object
S_PACMAN pacman;
void pacman_draw(uint8_t i, uint8_t j, uint16_t color);
void pacman_direction_process(void);
void pacman_moving_process(void);

// Ghost object
S_GHOST ghost;
void ghost_draw(uint8_t i, uint8_t j, uint16_t color);
void ghost_direction_process(void);
void ghost_moving_process(void);

// maze object
S_MAZE maze;
void pac_dot_draw(uint8_t i, uint8_t j, uint16_t color);

// Game object
void game_draw(void);
void game_handler(void);

/* Declare Private Support Functions */
uint8_t is_button_up(void);
uint8_t is_button_down(void);
uint8_t is_button_left(void);
uint8_t is_button_right(void);

/* Public Functions */
void game_init(void) {
	lcd_clear(BACKGROUND_COLOR);
	lcd_draw_rectangle(20, 20, 220, 220, BLACK);
	lcd_show_string(20, 230, "Extremely simple PAC-MAN", BLACK,
	BACKGROUND_COLOR, 16, 0);
	lcd_show_string(20, 250, "Score: ", BLACK, BACKGROUND_COLOR, 16, 0);

	led_7seg_set_digit(0, 0, 0);
	led_7seg_set_digit(0, 1, 0);
	led_7seg_set_digit(0, 2, 0);
	led_7seg_set_digit(0, 3, 0);

	for (uint8_t i = 0; i < MAZE_COLUMN_N; i++) {
		for (uint8_t j = 0; j < MAZE_ROW_N; j++) {
			maze.cells[i][j].is_pac_dot = 1;

			pac_dot_draw(i, j, BROWN);
		}
	}

	pacman.direction = STOP;
	pacman.i_pre = 5;
	pacman.j_pre = 5;
	pacman.i = 5;
	pacman.j = 5;
	pacman.score = 0;
	maze.cells[pacman.i][pacman.j].is_pac_dot = 0;
	pacman_draw(pacman.i, pacman.j, PACMAN_COLOR);

	srand(time(NULL));
	ghost.direction = DOWN;
	ghost.i_pre = 2;
	ghost.j_pre = 2;
	ghost.i = 2;
	ghost.j = 2;
	ghost_draw(ghost.i, ghost.j, GHOST_COLOR);
}

/* Private Functions */
void game_process(void) {
	static uint8_t counter_game = 0;
	counter_game = (counter_game + 1) % 5;

	pacman_direction_process();

	if (counter_game == 0) {
		pacman_moving_process();
		ghost_moving_process();

		game_handler();

		game_draw();
	}
}

void game_draw(void) {
	// delete old location
	pacman_draw(pacman.i_pre, pacman.j_pre, BACKGROUND_COLOR);
	ghost_draw(ghost.i_pre, ghost.j_pre, BACKGROUND_COLOR);

	// draw pac_dot again
	if (maze.cells[ghost.i_pre][ghost.j_pre].is_pac_dot == 1)
		pac_dot_draw(ghost.i_pre, ghost.j_pre, BROWN);

	// draw new location
	pacman_draw(pacman.i, pacman.j, PACMAN_COLOR);
	ghost_draw(ghost.i, ghost.j, GHOST_COLOR);

	// update score
	lcd_show_int_num(80, 250, pacman.score, 3, GHOST_COLOR, BACKGROUND_COLOR,
			16);
	led_7seg_set_digit(0, 0, 0);
	led_7seg_set_digit(0, 1, 0);
	led_7seg_set_digit(pacman.score / 10, 2, 0);
	led_7seg_set_digit(pacman.score % 10, 3, 0);
}

void game_handler(void) {
	// Game Over
	if ((pacman.i == ghost.i && pacman.j == ghost.j)
			|| ((pacman.i == ghost.i_pre && pacman.j == ghost.j_pre)
					&& (pacman.i_pre == ghost.i && pacman.j_pre == ghost.j))) {
		lcd_clear(BACKGROUND_COLOR);
		lcd_show_string(88, 160, "LOSS", GHOST_COLOR, BACKGROUND_COLOR, 32, 0);
		HAL_Delay(1000);

		game_init();
		return;
	}

	// WIN
	if (pacman.score == 99) {
		lcd_clear(BACKGROUND_COLOR);
		lcd_show_string(88, 160, "WIN", GHOST_COLOR, BACKGROUND_COLOR, 32, 0);
		HAL_Delay(1000);

		game_init();
		return;
	}

	// PAC-MAN eats pac_dot.
	if (maze.cells[pacman.i][pacman.j].is_pac_dot == 1) {
		maze.cells[pacman.i][pacman.j].is_pac_dot = 0;
		pacman.score++;
	}
}

void pacman_direction_process(void) {
	if (is_button_up()) {
		pacman.direction = UP;
	}
	if (is_button_down()) {
		pacman.direction = DOWN;
	}
	if (is_button_left()) {
		pacman.direction = LEFT;
	}
	if (is_button_right()) {
		pacman.direction = RIGHT;
	}
}

void pacman_moving_process(void) {
	pacman_direction_process();

	switch (pacman.direction) {
	case UP:
		if (pacman.j == 0) {
			pacman.direction = STOP;
		} else {
			pacman.i_pre = pacman.i;
			pacman.j_pre = pacman.j;

			pacman.j--;
		}
		break;

	case DOWN:
		if (pacman.j == MAZE_ROW_N - 1) {
			pacman.direction = STOP;
		} else {
			pacman.i_pre = pacman.i;
			pacman.j_pre = pacman.j;

			pacman.j++;
		}
		break;

	case LEFT:
		if (pacman.i == 0) {
			pacman.direction = STOP;
		} else {
			pacman.i_pre = pacman.i;
			pacman.j_pre = pacman.j;

			pacman.i--;
		}
		break;

	case RIGHT:
		if (pacman.i == MAZE_COLUMN_N - 1) {
			pacman.direction = STOP;
		} else {
			pacman.i_pre = pacman.i;
			pacman.j_pre = pacman.j;

			pacman.i++;
		}
		break;

	case STOP:
		pacman.i_pre = pacman.i;
		pacman.j_pre = pacman.j;
		break;

	default:
		pacman.direction = STOP;
		break;
	}
}

void ghost_direction_process(void) {
	static uint8_t direction;
	direction = rand() % 4;

	switch (ghost.direction) {
	case UP:
		if (ghost.j == 0) {
			if (ghost.i == 0) {
				while (direction == UP || direction == LEFT) {
					direction = rand() % 4;
				}
			} else if (ghost.i == MAZE_COLUMN_N - 1) {
				while (direction == UP || direction == RIGHT) {
					direction = rand() % 4;
				}
			} else {
				while (direction == UP) {
					direction = rand() % 4;
				}
			}
		}
		break;

	case DOWN:
		if (ghost.j == MAZE_COLUMN_N - 1) {
			if (ghost.i == 0) {
				while (direction == DOWN || direction == LEFT) {
					direction = rand() % 4;
				}
			} else if (ghost.i == MAZE_COLUMN_N - 1) {
				while (direction == DOWN || direction == RIGHT) {
					direction = rand() % 4;
				}
			} else {
				while (direction == DOWN) {
					direction = rand() % 4;
				}
			}
		}
		break;

	case LEFT:
		if (ghost.i == 0) {
			if (ghost.j == 0) {
				while (direction == LEFT || direction == UP) {
					direction = rand() % 4;
				}
			} else if (ghost.j == MAZE_ROW_N - 1) {
				while (direction == LEFT || direction == DOWN) {
					direction = rand() % 4;
				}
			} else {
				while (direction == LEFT) {
					direction = rand() % 4;
				}
			}
		}
		break;

	case RIGHT:
		if (ghost.i == MAZE_COLUMN_N - 1) {
			if (ghost.j == 0) {
				while (direction == RIGHT || direction == UP) {
					direction = rand() % 4;
				}
			} else if (ghost.j == MAZE_ROW_N - 1) {
				while (direction == RIGHT || direction == DOWN) {
					direction = rand() % 4;
				}
			} else {
				while (direction == RIGHT) {
					direction = rand() % 4;
				}
			}
		}
		break;

	default:
		break;
	}

	ghost.direction = direction;
}

void ghost_moving_process(void) {
	ghost_direction_process();

	switch (ghost.direction) {
	case UP:
		ghost.i_pre = ghost.i;
		ghost.j_pre = ghost.j;

		if (ghost.j > 0) {
			ghost.j--;
		}
		break;
	case DOWN:
		ghost.i_pre = ghost.i;
		ghost.j_pre = ghost.j;

		if (ghost.j < MAZE_ROW_N - 1) {
			ghost.j++;
		}
		break;

	case LEFT:
		ghost.i_pre = ghost.i;
		ghost.j_pre = ghost.j;

		if (ghost.i > 0) {
			ghost.i--;
		}
		break;

	case RIGHT:
		ghost.i_pre = ghost.i;
		ghost.j_pre = ghost.j;

		if (ghost.i < MAZE_COLUMN_N - 1) {
			ghost.i++;
		}
		break;

	default:
		ghost.direction = UP;
		break;
	}
}

void pac_dot_draw(uint8_t i, uint8_t j, uint16_t color) {
	lcd_fill(MAZE_LEFT_BORDER + i * MAZE_CELL_WIDTH + 6,
	MAZE_TOP_BORDER + j * MAZE_CELL_WIDTH + 6,
	MAZE_LEFT_BORDER + i * MAZE_CELL_WIDTH + 14,
	MAZE_LEFT_BORDER + j * MAZE_CELL_WIDTH + 14, color);
}

void pacman_draw(uint8_t i, uint8_t j, uint16_t color) {
	lcd_draw_circle(
	MAZE_LEFT_BORDER + i * MAZE_CELL_WIDTH + (MAZE_CELL_WIDTH / 2),
	MAZE_LEFT_BORDER + j * MAZE_CELL_WIDTH + (MAZE_CELL_WIDTH / 2), color,
			MAZE_CELL_WIDTH / 2 - 1, 1);
}

void ghost_draw(uint8_t i, uint8_t j, uint16_t color) {
	lcd_draw_circle(
	MAZE_LEFT_BORDER + i * MAZE_CELL_WIDTH + (MAZE_CELL_WIDTH / 2),
	MAZE_LEFT_BORDER + j * MAZE_CELL_WIDTH + (MAZE_CELL_WIDTH / 2), color,
			MAZE_CELL_WIDTH / 2 - 1, 1);
}

uint8_t is_button_up(void) {
	if (button_count[1] > 0) {
		return 1;
	}
	return 0;
}

uint8_t is_button_down(void) {
	if (button_count[9] > 0) {
		return 1;
	}
	return 0;
}

uint8_t is_button_left(void) {
	if (button_count[4] > 0) {
		return 1;
	}
	return 0;
}

uint8_t is_button_right(void) {
	if (button_count[6] > 0) {
		return 1;
	}
	return 0;
}
