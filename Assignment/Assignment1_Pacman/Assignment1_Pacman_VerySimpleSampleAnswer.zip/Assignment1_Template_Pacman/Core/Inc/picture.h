/*
 * picture.h
 */

#ifndef INC_PICTURE_H_
#define INC_PICTURE_H_

/* Variables */
extern const unsigned char gImageLogo[16200];
extern const unsigned char gImagePic[86400];

#endif /* INC_PICTURE_H_ */
